# Change Log
All notable changes to the "helloworld" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

### [1.0.1]
- Add notes.

### [1.0.0]
- Fix bug: the problem that occurs in line content with comment symbol.

### [0.0.2]
- Add detail notes.
- fix bug.

## [0.0.1]
- A new extension for aligning the inline trailing comment.